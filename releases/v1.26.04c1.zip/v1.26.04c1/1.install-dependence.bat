@echo off
title Installer
npm init -y
pause
npm install uuid nodemailer multer express -y
pause