function getUrlParams() {
    const params = new URLSearchParams(window.location.search);
    return {
        type: params.get('type'),
        code: params.get('code'),
        email: params.get('email'),
        reg: params.get('reg')
    };
}


function submitVerify() {
    const code = document.getElementById('verifyCode').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const email = document.getElementById('email').value;
    
    if (!code || !username || !password || !email) {
        alert('请填写所有字段');
        return;
    }
    
    const md5Password = md5(password);
    
    fetch('http://localhost:10377/account/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            username,
            password: md5Password,
            email
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.return === 'success') {
            showStep2(data.account_uid, data.account_name);
        } else {
            showError(data.return_text);
        }
    })
    .catch(err => {
        showError('网络错误');
    });
}

function showStep2(uid, name) {
    document.getElementById('step1').classList.add('hidden');
    document.getElementById('step2').classList.remove('hidden');
    document.getElementById('successUid').textContent = uid;
}

function showError(text) {
    document.getElementById('step1').classList.add('hidden');
    document.getElementById('error').classList.remove('hidden');
    document.getElementById('errorText').textContent = text;
}

function goToLogin() {
    window.location.href = 'hxgo://login';
}

function resendCode() {
    const email = document.getElementById('email').value;
    if (!email) {
        alert('请先输入邮箱');
        return;
    }
    
    const dacode = getDacode();
    
    fetch(`http://localhost:10377/account/verify?type=register&verify=${dacode}&email=${encodeURIComponent(email)}`)
        .then(res => res.json())
        .then(data => {
            alert(data.return_text);
        });
}

function getDacode() {
    const now = new Date();
    return `${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}${String(now.getHours()).padStart(2,'0')}`;
}

function md5(string) {
    return string; 
}
