const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
  const { choice, vkey } = req.query;
  const vkeyData = utils.validateVkey(vkey);
  if (!vkeyData) {
    return res.json({
      return: "failed",
      numbers: "0",
      data: []
    });
  }
  if (!choice) {
    return res.json({
      return: "failed",
      numbers: "0",
      data: []
    });
  }
  const introDir = path.join(__dirname, '../../storages/introductions', choice);
  if (!fs.existsSync(introDir)) {
    return res.json({
      return: "failed",
      numbers: "0",
      data: []
    });
  }
  const files = fs.readdirSync(introDir).filter(f => f.endsWith('.conf'));
  const result = {
    return: "success",
    numbers: String(files.length)
  };
  files.forEach((file, index) => {
    const confPath = path.join(introDir, file);
    const conf = utils.readConf(confPath);
    
    if (conf) {
      const appid = file.replace('.conf', '');
      result[`[${index + 1}]`] = {
        name_cn: conf.name || appid,
        name_en: enMap[conf.name] || conf.name || appid,
        appid: appid
      };
    }
  });
  res.json(result);
});
module.exports = router;
