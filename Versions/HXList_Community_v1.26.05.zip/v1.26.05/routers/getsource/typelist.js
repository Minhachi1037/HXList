const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
  const { vkey } = req.query;
  const vkeyData = utils.validateVkey(vkey);
  if (!vkeyData) {
    return res.json({
      return: "failed",
      numbers: "0",
      data: []
    });
  }
  const appsDir = path.join(__dirname, '../../storages/applications');
  if (!fs.existsSync(appsDir)) {
    return res.json({
      return: "success",
      numbers: "0",
      data: []
    });
  }
  const categories = fs.readdirSync(appsDir).filter(f => {
    return fs.statSync(path.join(appsDir, f)).isDirectory();
  });
  const result = {
    return: "success",
    numbers: String(categories.length)
  };

  categories.forEach((cat, index) => {
    const enMap = {
      '工具': 'Tool Apps',
      '游戏': 'Game Apps',
      '社交': 'Communication Apps',
      '视频': 'Video Apps',
      '音乐': 'Music Apps',
      '学习': 'Study Apps',
      '翻译笔专区': 'DictPen Apps',
      '手表专区': 'Watch Apps',
      'SOTA软件': 'SOTA Apps',
      '其他': 'Others'
    };
    result[`[${index + 1}]`] = {
      cn: cat,
      en: enMap[cat] || cat
    };
  });
  res.json(result);
});
module.exports = router;
