const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
    const { appid, vkey } = req.query;

    const vkeyData = utils.validateVkey(vkey);
    if (!vkeyData) {
        return res.status(403).json({
            return: "failed",
            return_text: "VKEY验证失败或已过期"
        });
    }

    if (!appid) {
        return res.status(400).json({
            return: "failed",
            return_text: "缺少appid参数"
        });
    }

    const picPath = path.join(__dirname, '../../storages/pictures', `${appid}.png`);

    if (!fs.existsSync(picPath)) {
        return res.status(404).json({
            return: "failed",
            return_text: "图片不存在"
        });
    }

    res.setHeader('Content-Type', 'image/png');
    const stream = fs.createReadStream(picPath);
    stream.pipe(res);

    stream.on('error', (err) => {
        if (!res.headersSent) {
            res.status(500).json({
                return: "failed",
                return_text: "图片读取错误"
            });
        }
    });
});

module.exports = router;
