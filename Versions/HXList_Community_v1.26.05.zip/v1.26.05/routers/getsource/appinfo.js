const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
  const { appid, vkey } = req.query;
  const vkeyData = utils.validateVkey(vkey);
  if (!vkeyData) {
    return res.json({
      return: "failed",
      appid: "",
      name: "",
      package_name: "",
      size: "",
      developer: "",
      minium_sdk: "",
      device: "",
      introduct: ""
    });
  }
  if (!appid) {
    return res.json({
      return: "failed",
      appid: "",
      name: "",
      package_name: "",
      size: "",
      developer: "",
      minium_sdk: "",
      device: "",
      introduct: ""
    });
  }
  const introDir = path.join(__dirname, '../../storages/introductions');
  let targetConf = null;
  if (fs.existsSync(introDir)) {
    const categories = fs.readdirSync(introDir).filter(f => {
      return fs.statSync(path.join(introDir, f)).isDirectory();
    });
    for (const cat of categories) {
      const confPath = path.join(introDir, cat, `${appid}.conf`);
      if (fs.existsSync(confPath)) {
        targetConf = utils.readConf(confPath);
        break;
      }
    }
  }
  if (!targetConf) {
    return res.json({
      return: "failed",
      appid: appid,
      name: "",
      package_name: "",
      size: "",
      developer: "",
      minium_sdk: "",
      device: "",
      introduct: "未找到该应用"
    });
  }
  res.json({
    return: "success",
    appid: targetConf.appid || appid,
    name: targetConf.name || "",
    package_name: targetConf.package_name || "",
    size: targetConf.size || "",
    developer: targetConf.developer || "",
    minium_sdk: targetConf.minium_sdk || "",
    device: targetConf.device || "",
    introduct: targetConf.introduct || ""
  });
});
module.exports = router;
