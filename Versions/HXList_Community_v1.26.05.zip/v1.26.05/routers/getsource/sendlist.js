const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
  const { vkey } = req.query;
  const vkeyData = utils.validateVkey(vkey);
  if (!vkeyData) {
    return res.json({
      return: "failed",
      numbers: "0",
      data: []
    });
  }
  const introDir = path.join(__dirname, '../../storages/introductions');
  const allApps = [];
  if (fs.existsSync(introDir)) {
    const categories = fs.readdirSync(introDir).filter(f => {
      return fs.statSync(path.join(introDir, f)).isDirectory();
    });
    categories.forEach(cat => {
      const catDir = path.join(introDir, cat);
      const files = fs.readdirSync(catDir).filter(f => f.endsWith('.conf'));
      files.forEach(file => {
        const confPath = path.join(catDir, file);
        const conf = utils.readConf(confPath);
        if (conf) {
          allApps.push({
            name_cn: conf.name || file.replace('.conf', ''),
            name_en: conf.name || file.replace('.conf', ''),
            appid: file.replace('.conf', ''),
            category: cat
          });
        }
      });
    });
  }
  const shuffled = allApps.sort(() => 0.5 - Math.random());
  const selected = shuffled.slice(0, 16);
  const result = {
    return: "success",
    numbers: String(selected.length)
  };
  selected.forEach((app, index) => {
    result[`[${index + 1}]`] = {
      name_cn: app.name_cn,
      name_en: app.name_en,
      appid: app.appid
    };
  });
  res.json(result);
});

module.exports = router;
