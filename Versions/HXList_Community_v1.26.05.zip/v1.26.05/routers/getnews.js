const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
  const { id, vkey } = req.query;
  const vkeyData = utils.validateVkey(vkey);
  if (!vkeyData) {
    return res.json({
      news_id: id || "",
      text: ""
    });
  }

  if (!id) {
    return res.json({
      news_id: "",
      text: ""
    });
  }
  const newsPath = path.join(__dirname, '../news', `${id}.conf`);
  if (!fs.existsSync(newsPath)) {
    return res.json({
      news_id: id,
      text: "公告不存在"
    });
  }
  const newsData = utils.readConf(newsPath);
  res.json({
    news_id: newsData?.news_id || id,
    text: newsData?.text || ""
  });
});

module.exports = router;
