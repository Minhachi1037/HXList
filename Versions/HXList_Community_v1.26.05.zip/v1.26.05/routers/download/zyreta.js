const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
  const { name, key, vkey } = req.query;
  const vkeyData = utils.validateVkey(vkey);
  if (!vkeyData) {
    return res.json({
      return: "failed",
      return_text: "VKEY验证失败或已过期"
    });
  }
  if (!name || !key) {
    return res.json({
      return: "failed",
      return_text: "缺少参数"
    });
  }
  const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const expectedKey = `${today}_${vkeyData.vkey.substring(0, 10)}`;
  if (key !== expectedKey) {
    return res.json({
      return: "failed",
      return_text: "CSRSecureKey校验失败"
    });
  }
  const sysDir = path.join(__dirname, '../../storages/system_files');
  const filePath = path.join(sysDir, name);
  if (!fs.existsSync(filePath)) {
    return res.json({
      return: "failed",
      return_text: "没有找到这个程序，请检查是否存在"
    });
  }
  res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
  const stream = fs.createReadStream(filePath);
  stream.pipe(res);
  stream.on('error', (err) => {
    console.error(err);
    if (!res.headersSent) {
      res.json({
        return: "failed",
        return_text: "文件读取错误"
      });
    }
  });
});
module.exports = router;
