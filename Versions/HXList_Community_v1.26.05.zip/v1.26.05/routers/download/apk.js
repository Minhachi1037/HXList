const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
  const { appid, vkey } = req.query;
  const vkeyData = utils.validateVkey(vkey);
  if (!vkeyData) {
    return res.json({
      return: "failed",
      return_text: "VKEY验证失败或已过期"
    });
  }
  if (!appid) {
    return res.json({
      return: "failed",
      return_text: "缺少appid参数"
    });
  }
  const appsDir = path.join(__dirname, '../../storages/applications');
  let apkPath = null;
  if (fs.existsSync(appsDir)) {
    const categories = fs.readdirSync(appsDir).filter(f => {
      return fs.statSync(path.join(appsDir, f)).isDirectory();
    });
    for (const cat of categories) {
      const testPath = path.join(appsDir, cat, `${appid}.apk`);
      if (fs.existsSync(testPath)) {
        apkPath = testPath;
        break;
      }
    }
  }
  if (!apkPath) {
    return res.json({
      return: "failed",
      return_text: "没有找到这个程序，请检查是否存在"
    });
  }
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', `attachment; filename="${appid}.apk"`);
  const stream = fs.createReadStream(apkPath);
  stream.pipe(res);
  stream.on('error', (err) => {
    console.error(err);
    if (!res.headersSent) {
      res.json({
        return: "failed",
        return_text: "文件读取错误"
      });
    }
  });
});

module.exports = router;
