const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
  const { vkey } = req.query;
  if (vkey) {
    const vkeyData = utils.validateVkey(vkey);
    if (!vkeyData) {
      return res.json({
        return: "failed",
        return_text: "VKEY验证失败"
      });
    }
  }
  const clientPath = path.join(__dirname, '../client.conf');
  if (!fs.existsSync(clientPath)) {
    return res.json({
      latest: "",
      latest_name: ""
    });
  }
  const clientData = utils.readConf(clientPath);
  res.json({
    latest: clientData?.latest || "",
    latest_name: clientData?.latest_name || ""
  });
});
module.exports = router;
