const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
  const { userid, email, password, ipc } = req.query;
  if ((!userid && !email) || !password || !ipc) {
    return res.json({
      request_type: "login",
      return: "failed",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "参数不完整",
      latest_news: "",
      current: utils.generateCurrent()
    });
  }
  const accountsDir = path.join(__dirname, '../../accounts');
  let targetUid = null;
  let targetProfile = null;
  if (fs.existsSync(accountsDir)) {
    const uids = fs.readdirSync(accountsDir);
    for (const uid of uids) {
      const profilePath = path.join(accountsDir, uid, 'profile.conf');
      if (fs.existsSync(profilePath)) {
        const profile = utils.readConf(profilePath);
        if (!profile) continue;
        if (userid && profile.account_uid === userid) {
          targetUid = uid;
          targetProfile = profile;
          break;
        }
        if (email && profile.email === email) {
          targetUid = uid;
          targetProfile = profile;
          break;
        }
      }
    }
  }
  if (!targetProfile) {
    return res.json({
      request_type: "login",
      return: "failed",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "用户不存在",
      latest_news: "",
      current: utils.generateCurrent()
    });
  }
  if (targetProfile.password !== password) {
    return res.json({
      request_type: "login",
      return: "failed",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "密码错误",
      latest_news: "",
      current: utils.generateCurrent()
    });
  }
  try {
    const keysDir = path.join(__dirname, '../../keys');
    const userKeyDir = path.join(keysDir, targetUid);
    fs.mkdirSync(userKeyDir, { recursive: true });
    const vkey = utils.generateVkey();
    const vkeyData = {
      vkey: vkey,
      latest: utils.getNowTime()
    };
    utils.writeConf(path.join(userKeyDir, 'vkey.conf'), vkeyData);
    let latestNews = "";
    const newsDir = path.join(__dirname, '../../news');
    if (fs.existsSync(newsDir)) {
      const newsFiles = fs.readdirSync(newsDir);
      if (newsFiles.length > 0) {
        newsFiles.sort();
        latestNews = newsFiles[newsFiles.length - 1].replace('.conf', '');
      }
    }
    res.json({
      request_type: "login",
      return: "success",
      vkey: vkey,
      account_uid: targetProfile.account_uid,
      account_name: targetProfile.account_name,
      develope_mode: targetProfile.developer || "false",
      return_text: "登录成功",
      latest_news: latestNews,
      current: utils.generateCurrent()
    });
  } catch (error) {
    res.json({
      request_type: "login",
      return: "failed",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "登录处理失败: " + error.message,
      latest_news: "",
      current: utils.generateCurrent()
    });
  }
});
module.exports = router;
