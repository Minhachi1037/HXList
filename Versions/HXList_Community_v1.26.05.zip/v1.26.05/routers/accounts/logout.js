const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', (req, res) => {
  const { vkey } = req.query;
  if (!vkey) {
    return res.json({
      request_type: "logout",
      return: "failed",
      return_text: "缺少vkey参数",
      current: utils.generateCurrent()
    });
  }
  const keysDir = path.join(__dirname, '../../keys');
  let deleted = false;
  if (fs.existsSync(keysDir)) {
    const uids = fs.readdirSync(keysDir);
    for (const uid of uids) {
      const vkeyPath = path.join(keysDir, uid, 'vkey.conf');
      if (fs.existsSync(vkeyPath)) {
        const vkeyData = utils.readConf(vkeyPath);
        if (vkeyData && vkeyData.vkey === vkey) {
          fs.rmSync(path.join(keysDir, uid), { recursive: true, force: true });
          deleted = true;
          break;
        }
      }
    }
  }
  if (deleted) {
    res.json({
      request_type: "logout",
      return: "success",
      return_text: "退出登录成功",
      current: utils.generateCurrent()
    });
  } else {
    res.json({
      request_type: "logout",
      return: "failed",
      return_text: "VKEY不存在或已过期",
      current: utils.generateCurrent()
    });
  }
});

module.exports = router;
