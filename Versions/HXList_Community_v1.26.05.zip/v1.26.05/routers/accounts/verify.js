const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');

router.get('/', async (req, res) => {
  const { type, verify, email } = req.query;
  if (!type || !verify || !email) {
    return res.json({
      request_type: "verify",
      return: "failed",
      return_text: "参数不完整",
      current: utils.generateCurrent()
    });
  }
  if (!email.includes('@') || !email.includes('.')) {
    return res.json({
      request_type: "verify",
      return: "failed",
      return_text: "邮箱格式不正确",
      current: utils.generateCurrent()
    });
  }
  const smtpPath = path.join(__dirname, '../../smtp.conf');
  const smtpContent = fs.readFileSync(smtpPath, 'utf8');
  const smtpConfig = {};
  const lines = smtpContent.split('\n');
  lines.forEach(line => {
    const match = line.match(/"([^"]+)":\s*"([^"]+)"/);
    if (match) smtpConfig[match[1]] = match[2];
  });
  try {
    const transporter = nodemailer.createTransport({
      host: smtpConfig.smtp_host,
      port: parseInt(smtpConfig.smtp_port),
      secure: smtpConfig.secure === 'true',
      auth: {
        user: smtpConfig.auth_user,
        pass: smtpConfig.auth_pass
      }
    });
    let subject, text, verifyLink;
    if (type === 'register') {
      subject = smtpConfig.register_subject;
      verifyLink = `${smtpConfig.verify_web_url}?type=register&code=${verify}&email=${encodeURIComponent(email)}`;
      text = smtpConfig.register_text.replace('{verify_link}', verifyLink);
    } else if (type === 'findback') {
      subject = smtpConfig.findback_subject;
      verifyLink = `${smtpConfig.verify_web_url}?type=findback&code=${verify}&email=${encodeURIComponent(email)}`;
      text = smtpConfig.findback_text.replace('{verify_link}', verifyLink);
    } else {
      return res.json({
        request_type: "verify",
        return: "failed",
        return_text: "不支持的验证类型",
        current: utils.generateCurrent()
      });
    }
    await transporter.sendMail({
      from: `"${smtpConfig.from_name}" <${smtpConfig.auth_user}>`,
      to: email,
      subject: subject,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2>验证您在 HXGo 上的账户邮箱</h2>
          <p>HXGo向您发送了一封注册链接的信件</p>
          <p>点击此链接验证您的邮箱并完成：</p>
          <p><a href="${verifyLink}" style="color: #0066cc; word-break: break-all;">${verifyLink}</a></p>
          <p>链接有效期15分钟，不要告诉任何人，请保存好密码防止丢失</p>
          <p>©2026 幻星软件.</p>
        </div>
      `
    });
    res.json({
      request_type: "verify",
      return: "success",
      return_text: "验证码发送成功，请检查邮箱",
      current: utils.generateCurrent()
    });
  } catch (error) {
    res.json({
      request_type: "verify",
      return: "failed",
      return_text: "发送失败: " + error.message,
      current: utils.generateCurrent()
    });
  }
});

module.exports = router;
