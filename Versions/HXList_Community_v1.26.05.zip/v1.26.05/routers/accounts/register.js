const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

let registerService;
try {
  registerService = require('../../register_server.js');
} catch (e) {
  registerService = null;
}

function generateRegisterId() {
  const uuid = uuidv4().replace(/-/g, '');
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 8);
  return `${uuid}_${timestamp}_${random}`;
}

router.post('/', async (req, res) => {
  const { username, password, email, ipc } = req.body;
  if (!username || !password || !email) {
    return res.json({
      request_type: "register",
      return: "failed",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "参数不完整",
      current: utils.generateCurrent()
    });
  }
  if (!email.includes('@') || !email.includes('.')) {
    return res.json({
      request_type: "register",
      return: "failed",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "邮箱格式不正确",
      current: utils.generateCurrent()
    });
  }
  const accountsDir = path.join(__dirname, '../../accounts');
  if (fs.existsSync(accountsDir)) {
    const uids = fs.readdirSync(accountsDir);
    for (const uid of uids) {
      const profilePath = path.join(accountsDir, uid, 'profile.conf');
      if (fs.existsSync(profilePath)) {
        const profile = utils.readConf(profilePath);
        if (profile && profile.email === email) {
          return res.json({
            request_type: "register",
            return: "failed",
            vkey: "",
            account_uid: "",
            account_name: "",
            develope_mode: "",
            return_text: "邮箱已被注册",
            current: utils.generateCurrent()
          });
        }
      }
    }
  }
  try {
    const nodemailer = require('nodemailer');
    const smtpPath = path.join(__dirname, '../../smtp.conf');
    const smtpContent = fs.readFileSync(smtpPath, 'utf8');
    const smtpConfig = {};
    const lines = smtpContent.split('\n');
    lines.forEach(line => {
      const match = line.match(/"([^"]+)":\s*"([^"]+)"/);
      if (match) smtpConfig[match[1]] = match[2];
    });
    const registerId = generateRegisterId();
    const pendingDir = path.join(__dirname, '../../temp');
    if (!fs.existsSync(pendingDir)) fs.mkdirSync(pendingDir, { recursive: true });
    const pendingData = {
      username,
      password,
      email,
      createTime: Date.now(),
      registerId
    };
    fs.writeFileSync(path.join(pendingDir, `${registerId}.json`), JSON.stringify(pendingData));
    const transporter = nodemailer.createTransport({
      host: smtpConfig.smtp_host,
      port: parseInt(smtpConfig.smtp_port),
      secure: smtpConfig.secure === 'true',
      auth: {
        user: smtpConfig.auth_user,
        pass: smtpConfig.auth_pass
      }
    });
    const verifyLink = `http://localhost?reg=${registerId}`;
    
    await transporter.sendMail({
      from: `"${smtpConfig.from_name}" <${smtpConfig.auth_user}>`,
      to: email,
      subject: smtpConfig.register_subject || 'HXGo 注册',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2>验证您在 HXGo 上的账户邮箱</h2>
          <p>HXGo向您发送了一封注册链接的信件</p>
          <p>点击此链接验证您的邮箱并完成：</p>
          <p><a href="${verifyLink}" style="color: #0066cc; word-break: break-all;">${verifyLink}</a></p>
          <p>链接有效期15分钟，不要告诉任何人，请保存好密码防止丢失</p>
          <p>©2026 幻星软件.</p>
        </div>
      `
    });

    setTimeout(() => {
      const filePath = path.join(pendingDir, `${registerId}.json`);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }, 15 * 60 * 1000);
    res.json({
      request_type: "register",
      return: "success",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "验证邮件已发送，请检查邮箱并点击链接完成注册",
      current: utils.generateCurrent()
    });
  } catch (error) {
    console.error('[注册邮件发送失败]', error);
    res.json({
      request_type: "register",
      return: "failed",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "邮件发送失败: " + error.message,
      current: utils.generateCurrent()
    });
  }
});

router.get('/', (req, res) => {
  const { reg } = req.query;
  if (!reg) {
    return res.json({
      request_type: "register",
      return: "failed",
      return_text: "缺少注册ID参数",
      current: utils.generateCurrent()
    });
  }
  const pendingPath = path.join(__dirname, '../../temp', `${reg}.json`);
  if (!fs.existsSync(pendingPath)) {
    return res.json({
      request_type: "register_verify",
      return: "failed",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "注册链接已过期或无效",
      current: utils.generateCurrent()
    });
  }
  const pendingData = JSON.parse(fs.readFileSync(pendingPath, 'utf8'));
  if (Date.now() - pendingData.createTime > 15 * 60 * 1000) {
    fs.unlinkSync(pendingPath);
    return res.json({
      request_type: "register_verify",
      return: "failed",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "注册链接已过期",
      current: utils.generateCurrent()
    });
  }
  try {
    const accountsDir = path.join(__dirname, '../../accounts');
    const keysDir = path.join(__dirname, '../../keys');
    
    let maxUid = 0;
    if (fs.existsSync(accountsDir)) {
      const dirs = fs.readdirSync(accountsDir);
      dirs.forEach(dir => {
        const num = parseInt(dir);
        if (!isNaN(num) && num > maxUid) maxUid = num;
      });
    }
    const newUid = maxUid + 1;
    const userDir = path.join(accountsDir, String(newUid));
    const userKeyDir = path.join(keysDir, String(newUid));
    fs.mkdirSync(userDir, { recursive: true });
    fs.mkdirSync(userKeyDir, { recursive: true });
    const profileData = {
      password: pendingData.password,
      developer: "false",
      account_name: pendingData.username,
      account_uid: String(newUid),
      email: pendingData.email
    };
    utils.writeConf(path.join(userDir, 'profile.conf'), profileData);
    const vkey = utils.generateVkey();
    const vkeyData = {
      vkey: vkey,
      latest: utils.getNowTime()
    };
    utils.writeConf(path.join(userKeyDir, 'vkey.conf'), vkeyData);
    fs.unlinkSync(pendingPath);
    res.json({
      request_type: "register_verify",
      return: "success",
      vkey: vkey,
      account_uid: String(newUid),
      account_name: pendingData.username,
      develope_mode: "false",
      return_text: "注册成功，请登录",
      current: utils.generateCurrent()
    });
  } catch (error) {
    res.json({
      request_type: "register_verify",
      return: "failed",
      vkey: "",
      account_uid: "",
      account_name: "",
      develope_mode: "",
      return_text: "注册失败: " + error.message,
      current: utils.generateCurrent()
    });
  }
});
module.exports = router;
