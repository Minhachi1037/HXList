// HXList v1.25.05
// 构建日期: 2026年 05月 7日 15:56:49(UTC+8)
// © 2026 HXSoftware. Open Sourced by APACHE 2.0 Lisence

const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const CONFIG = {
    debugmode: false,
    backendIP: "38.244.14.70",
    getBackendUrl() {
        return this.debugmode ? 'localhost' : (this.backendIP || 'localhost');
    },
    getMainApiUrl() {
        return `http://${this.getBackendUrl()}:10377`;
    },
    getVerifyUrl() {
        const host = this.getBackendUrl();
        return host === 'localhost' ? `http://${host}` : `http://${host}`;
    }
};
const configPath = path.join(__dirname, 'server.conf');
if (fs.existsSync(configPath)) {
    try {
        const content = fs.readFileSync(configPath, 'utf8');
        const lines = content.split('\n');
        lines.forEach(line => {
            const match = line.match(/(\w+)="([^"]+)"/);
            if (match) {
                const key = match[1];
                const value = match[2];
                if (key === 'debugmode') {
                    CONFIG.debugmode = value === 'true';
                } else if (key === 'backendIP') {
                    CONFIG.backendIP = value;
                }
            }
        });
    } catch (e) {
    }
} else {
    const defaultConfig = `{
    debugmode="false",
    backendIP="38.244.14.70"
}`;
    fs.writeFileSync(configPath, defaultConfig, 'utf8');
}
const utils = {
    generateCurrent() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < 15; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    },

    generateVkey() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < 30; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    },

    md5(str) {
        return crypto.createHash('md5').update(str).digest('hex');
    },

    readConf(filePath) {
        try {
            const content = fs.readFileSync(filePath, 'utf8');
            const data = {};
            const lines = content.split('\n');
            lines.forEach(line => {
                const match = line.match(/(\w+)="([^"]+)"/);
                if (match) {
                    data[match[1]] = match[2];
                }
            });
            return data;
        } catch (e) {
            return null;
        }
    },

    writeConf(filePath, data) {
        let content = '{\n';
        const entries = Object.entries(data);
        entries.forEach(([key, value], index) => {
            const comma = index < entries.length - 1 ? ',' : '';
            content += `    ${key}="${value}"${comma}\n`;
        });
        content += '}';
        fs.writeFileSync(filePath, content, 'utf8');
    },

    ensureDir(dir) {
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
    },

    getNowTime() {
        const now = new Date();
        return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    },

    validateVkey(vkey) {
        if (!vkey) return false;
        const keysDir = path.join(__dirname, 'keys');
        if (!fs.existsSync(keysDir)) return false;
        
        const uidDirs = fs.readdirSync(keysDir);
        for (const uid of uidDirs) {
            const vkeyPath = path.join(keysDir, uid, 'vkey.conf');
            if (fs.existsSync(vkeyPath)) {
                const vkeyData = this.readConf(vkeyPath);
                if (vkeyData && vkeyData.vkey === vkey) {
                    const latest = vkeyData.latest;
                    if (latest) {
                        const [h, m, s] = latest.split(':').map(Number);
                        const latestTime = new Date();
                        latestTime.setHours(h, m, s);
                        const now = new Date();
                        const diff = (now - latestTime) / 1000 / 60;
                        if (diff > 30) return false;
                    }
                    vkeyData.latest = this.getNowTime();
                    this.writeConf(vkeyPath, vkeyData);
                    return { uid, ...vkeyData };
                }
            }
        }
        return false;
    }
};

global.utils = utils;
function generateRegisterId() {
    const uuid = uuidv4().replace(/-/g, '');
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    return `${uuid}_${timestamp}_${random}`;
}

function completeRegister(pendingData) {
    try {
        const accountsDir = path.join(__dirname, 'accounts');
        const keysDir = path.join(__dirname, 'keys');
        
        let maxUid = 0;
        if (fs.existsSync(accountsDir)) {
            const dirs = fs.readdirSync(accountsDir);
            dirs.forEach(dir => {
                const num = parseInt(dir);
                if (!isNaN(num) && num > maxUid) maxUid = num;
            });
        }
        const newUid = maxUid + 1;

        const userDir = path.join(accountsDir, String(newUid));
        const userKeyDir = path.join(keysDir, String(newUid));
        
        utils.ensureDir(userDir);
        utils.ensureDir(userKeyDir);

        const profileData = {
            password: pendingData.password,
            developer: "false",
            account_name: pendingData.username,
            account_uid: String(newUid),
            email: pendingData.email
        };
        utils.writeConf(path.join(userDir, 'profile.conf'), profileData);

        const vkey = utils.generateVkey();
        const vkeyData = {
            vkey: vkey,
            latest: utils.getNowTime()
        };
        utils.writeConf(path.join(userKeyDir, 'vkey.conf'), vkeyData);
        const pendingPath = path.join(__dirname, 'temp', `${pendingData.registerId || pendingData.register_id || 'unknown'}.json`);
        if (fs.existsSync(pendingPath)) fs.unlinkSync(pendingPath);

        return {
            success: true,
            vkey: vkey,
            account_uid: String(newUid),
            account_name: pendingData.username,
            develope_mode: "false"
        };
    } catch (error) {
        console.error('[注册失败]', error);
        return {
            success: false,
            message: error.message
        };
    }
}

function createMainApp() {
    const app = express();
    app.use((req, res, next) => {
        res.header('Access-Control-Allow-Origin', '*');
        res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
        
        if (req.method === 'OPTIONS') {
            return res.sendStatus(200);
        }
        next();
    });

    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));
    app.post('/account/register', async (req, res) => {
        console.log('[POST /account/register]', req.body);
        
        const { username, password, email } = req.body;

        if (!username || !password || !email) {
            return res.json({
                request_type: "register",
                return: "failed",
                vkey: "",
                account_uid: "",
                account_name: "",
                develope_mode: "",
                return_text: "参数不完整",
                current: utils.generateCurrent()
            });
        }

        if (!email.includes('@') || !email.includes('.')) {
            return res.json({
                request_type: "register",
                return: "failed",
                vkey: "",
                account_uid: "",
                account_name: "",
                develope_mode: "",
                return_text: "邮箱格式不正确",
                current: utils.generateCurrent()
            });
        }
        const accountsDir = path.join(__dirname, 'accounts');
        if (fs.existsSync(accountsDir)) {
            const uids = fs.readdirSync(accountsDir);
            for (const uid of uids) {
                const profilePath = path.join(accountsDir, uid, 'profile.conf');
                if (fs.existsSync(profilePath)) {
                    const profile = utils.readConf(profilePath);
                    if (profile && profile.email === email) {
                        return res.json({
                            request_type: "register",
                            return: "failed",
                            vkey: "",
                            account_uid: "",
                            account_name: "",
                            develope_mode: "",
                            return_text: "邮箱已被注册",
                            current: utils.generateCurrent()
                        });
                    }
                }
            }
        }
        try {
            const nodemailer = require('nodemailer');
            const smtpPath = path.join(__dirname, 'smtp.conf');
            
            if (!fs.existsSync(smtpPath)) {
                throw new Error('SMTP配置文件不存在');
            }
            
            const smtpContent = fs.readFileSync(smtpPath, 'utf8');
            const smtpConfig = {};
            const lines = smtpContent.split('\n');
            lines.forEach(line => {
                const match = line.match(/"([^"]+)":\s*"([^"]+)"/);
                if (match) smtpConfig[match[1]] = match[2];
            });

            const registerId = generateRegisterId();
            
            const pendingDir = path.join(__dirname, 'temp');
            utils.ensureDir(pendingDir);
            
            const pendingData = {
                username,
                password,
                email,
                createTime: Date.now(),
                registerId
            };
            fs.writeFileSync(path.join(pendingDir, `${registerId}.json`), JSON.stringify(pendingData));

            const transporter = nodemailer.createTransport({
                host: smtpConfig.smtp_host,
                port: parseInt(smtpConfig.smtp_port),
                secure: smtpConfig.secure === 'true',
                auth: {
                    user: smtpConfig.auth_user,
                    pass: smtpConfig.auth_pass
                },
                tls: { rejectUnauthorized: false }
            });

            try {
                await transporter.verify();
            } catch (verifyErr) {
                console.error('[SMTP] 连接验证失败:', verifyErr.message);
                throw new Error(`SMTP连接失败: ${verifyErr.message}`);
            }

            const verifyLink = `${CONFIG.getVerifyUrl()}?reg=${registerId}`;
            
            const info = await transporter.sendMail({
                from: `"${smtpConfig.from_name}" <${smtpConfig.auth_user}>`,
                to: email,
                subject: smtpConfig.register_subject || '验证您在 HXGo 上的账户邮箱',
                html: `
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                        <h2>验证您在 HXGo 上的账户邮箱</h2>
                        <p>您收到这封邮件，是因为有人在 HXGo 注册时使用了本邮箱地址。</p>
                        <p>点击此链接验证您的邮箱并完成注册：</p>
                        <p><a href="${verifyLink}" style="color: #0066cc; word-break: break-all;">${verifyLink}</a></p>
                        <p>链接有效期15分钟。</p>
                        <p>如果您并没有访问过我们的网站，或没有进行上述操作，请忽略这封邮件。</p>
                    </div>
                `
            });

            console.log(`messageId=${info.messageId}`);
            setTimeout(() => {
                const filePath = path.join(pendingDir, `${registerId}.json`);
                if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
            }, 15 * 60 * 1000);

            res.json({
                request_type: "register",
                return: "success",
                vkey: "",
                account_uid: "",
                account_name: "",
                develope_mode: "",
                return_text: "验证邮件已发送，请检查邮箱并点击链接完成注册",
                current: utils.generateCurrent()
            });

        } catch (error) {
            console.error('[注册邮件发送失败]', error);
            res.json({
                request_type: "register",
                return: "failed",
                vkey: "",
                account_uid: "",
                account_name: "",
                develope_mode: "",
                return_text: "邮件发送失败: " + error.message,
                current: utils.generateCurrent()
            });
        }
    });

    app.get('/account/register', (req, res) => {
        console.log('[GET /account/register]', req.query);
        
        const { reg } = req.query;
        
        if (!reg) {
            return res.json({
                request_type: "register",
                return: "failed",
                return_text: "缺少注册ID参数",
                current: utils.generateCurrent()
            });
        }

        const pendingPath = path.join(__dirname, 'temp', `${reg}.json`);
        
        if (!fs.existsSync(pendingPath)) {
            return handleRegisterError(req, res, "注册链接已过期或无效");
        }

        const pendingData = JSON.parse(fs.readFileSync(pendingPath, 'utf8'));
        
        if (Date.now() - pendingData.createTime > 15 * 60 * 1000) {
            fs.unlinkSync(pendingPath);
            return handleRegisterError(req, res, "注册链接已过期");
        }
        const result = completeRegister(pendingData);
        
        if (result.success) {
            if (req.headers.accept && req.headers.accept.includes('text/html')) {
                const testPageUrl = `${CONFIG.getMainApiUrl()}/test/test.html`;
                
                return res.send(`
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>HXGo FRHC</title>
                        <meta charset="UTF-8">
                        <style>
                            body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; background: #f5f5f5; }
                            .card { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); text-align: center; max-width: 400px; }
                            .success { color: #4CAF50; font-size: 64px; margin-bottom: 20px; }
                            h1 { color: #333; margin-bottom: 16px; }
                            p { color: #666; margin-bottom: 8px; }
                            .uid { font-size: 24px; font-weight: bold; color: #675A4E; margin: 16px 0; }
                            .btn { display: inline-block; margin-top: 20px; padding: 12px 24px; background: #675A4E; color: white; text-decoration: none; border-radius: 20px; }
                        </style>
                    </head>
                    <body>
                        <div class="card">
                            <h1>注册成功！</h1>
                            <p>您的账号 <strong>${result.account_name}</strong> 已创建成功</p>
                            <p class="uid">UID: ${result.account_uid}</p>
                            <p>请返回客户端使用邮箱和密码登录</p>
                        </div>
                    </body>
                    </html>
                `);
            }

            res.json({
                request_type: "register_verify",
                return: "success",
                vkey: result.vkey,
                account_uid: result.account_uid,
                account_name: result.account_name,
                develope_mode: result.develope_mode,
                return_text: "注册成功，请登录",
                current: utils.generateCurrent()
            });
        } else {
            res.json({
                request_type: "register_verify",
                return: "failed",
                vkey: "",
                account_uid: "",
                account_name: "",
                develope_mode: "",
                return_text: "注册失败: " + result.message,
                current: utils.generateCurrent()
            });
        }
    });
    const accountsDir = path.join(__dirname, 'routers', 'accounts');
    if (fs.existsSync(accountsDir)) {
        fs.readdirSync(accountsDir).forEach(file => {
            if (file.endsWith('.js') && file !== 'register.js') {
                const routePath = '/account/' + file.replace('.js', '');
                try {
                    app.use(routePath, require(path.join(accountsDir, file)));
                } catch (e) {
                    console.error(`[路由加载失败] ${routePath}: ${e.message}`);
                }
            }
        });
    }

    const getsourceDir = path.join(__dirname, 'routers', 'getsource');
    if (fs.existsSync(getsourceDir)) {
        fs.readdirSync(getsourceDir).forEach(file => {
            if (file.endsWith('.js')) {
                const routePath = '/getsource/' + file.replace('.js', '');
                app.use(routePath, require(path.join(getsourceDir, file)));
            }
        });
    }

    const downloadDir = path.join(__dirname, 'routers', 'download');
    if (fs.existsSync(downloadDir)) {
        fs.readdirSync(downloadDir).forEach(file => {
            if (file.endsWith('.js')) {
                const routePath = '/download/' + file.replace('.js', '');
                app.use(routePath, require(path.join(downloadDir, file)));
            }
        });
    }

    const otherRouters = ['getver.js', 'getnews.js'];
    otherRouters.forEach(file => {
        const filePath = path.join(__dirname, 'routers', file);
        if (fs.existsSync(filePath)) {
            const routePath = '/' + file.replace('.js', '');
            app.use(routePath, require(filePath));
        }
    });
    app.use('/test', express.static(path.join(__dirname, 'public')));
    app.get('/', (req, res) => {
        res.json({
            status: 'HXGo Main API Service',
            port: 10377,
            debugmode: CONFIG.debugmode,
            backendIP: CONFIG.getBackendUrl(),
            time: new Date().toISOString()
        });
    });

    return app;
}
function createVerifyApp() {
    const app = express();
    
    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));
    app.use(express.static(path.join(__dirname, 'public')));
    app.use(express.static(path.join(__dirname, 'frhc')));
    
    app.get('/', (req, res) => {
        const { reg } = req.query;
        
        if (!reg) {
            return res.send(`

                <html>
                <head><title>HXGo FRHC</title></head>
                <body>
                <center><h1>404</h1></center>
                <hr><center>HXList</center>
                </body>
                </html>
            `);
        }
        const pendingPath = path.join(__dirname, 'temp', `${reg}.json`);
        
        if (!fs.existsSync(pendingPath)) {
            return res.send(`
                <html>
                    <head><title>HXGo FRHC</title><meta charset="UTF-8"></head>
                    <body style="font-family: Arial; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; background: #f5f5f5;">
                        <div style="background: white; padding: 40px; border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); text-align: center; max-width: 400px;">
                            <h1>验证链接已过期或无效</h1>
                            <p>此注册链接已过期（有效期15分钟）或不存在。</p>
                            <p>请重新发起注册流程。</p>
                        </div>
                    </body>
                </html>
            `);
        }

        const pendingData = JSON.parse(fs.readFileSync(pendingPath, 'utf8'));
        
        if (Date.now() - pendingData.createTime > 15 * 60 * 1000) {
            fs.unlinkSync(pendingPath);
            return res.send(`
                <html>
                    <head><title>HXGo FRHC</title><meta charset="UTF-8"></head>
                    <body style="font-family: Arial; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; background: #f5f5f5;">
                        <div style="background: white; padding: 40px; border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); text-align: center; max-width: 400px;">
                            <h1>验证链接已过期</h1>
                            <p>此注册链接已超过15分钟有效期。</p>
                            <p>请重新发起注册流程。</p>
                        </div>
                    </body>
                </html>
            `);
        }
        const result = completeRegister(pendingData);
        
        if (result.success) {
            const testPageUrl = `${CONFIG.getMainApiUrl()}/test/test.html`;
            
            res.send(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>HXGo FRHC</title>
                    <meta charset="UTF-8">
                    <style>
                        body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; background: #f5f5f5; }
                        .card { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); text-align: center; max-width: 400px; }
                        .success { color: #4CAF50; font-size: 64px; margin-bottom: 20px; }
                        h1 { color: #333; margin-bottom: 16px; }
                        p { color: #666; margin-bottom: 8px; }
                        .uid { font-size: 24px; font-weight: bold; color: #675A4E; margin: 16px 0; }
                        .btn { display: inline-block; margin-top: 20px; padding: 12px 24px; background: #675A4E; color: white; text-decoration: none; border-radius: 20px; }
                    </style>
                </head>
                <body>
                    <div class="card">
                        <h1>注册成功！</h1>
                        <p>您的账号 <strong>${result.account_name}</strong> 已创建成功</p>
                        <p class="uid">UID: ${result.account_uid}</p>
                        <p>请返回客户端使用邮箱和密码登录</p>
                    </div>
                </body>
                </html>
            `);
        } else {
            res.send(`
                <html>
                    <head><title>HXGo FRHC</title><meta charset="UTF-8"></head>
                    <body style="font-family: Arial; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; background: #f5f5f5;">
                        <div style="background: white; padding: 40px; border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); text-align: center; max-width: 400px;">
                            <h1>注册失败</h1>
                            <p>${result.message}</p>
                        </div>
                    </body>
                </html>
            `);
        }
    });

    return app;
}

function handleRegisterError(req, res, message) {
    if (req.headers.accept && req.headers.accept.includes('text/html')) {
        return res.send(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>HXGo FRHC</title>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; background: #f5f5f5; }
                    .card { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); text-align: center; max-width: 400px; }
                    .error { color: #f44336; font-size: 64px; margin-bottom: 20px; }
                    h1 { color: #333; margin-bottom: 16px; }
                    p { color: #666; margin-bottom: 8px; }
                </style>
            </head>
            <body>
                <div class="card">
                    <h1>验证失败</h1>
                    <p>${message}</p>
                    <p>请重新发起注册流程。</p>
                </div>
            </body>
            </html>
        `);
    }

    return res.json({
        request_type: "register_verify",
        return: "failed",
        vkey: "",
        account_uid: "",
        account_name: "",
        develope_mode: "",
        return_text: message,
        current: utils.generateCurrent()
    });
}
function initDirs() {
    utils.ensureDir(path.join(__dirname, 'keys'));
    utils.ensureDir(path.join(__dirname, 'accounts'));
    utils.ensureDir(path.join(__dirname, 'storages', 'applications'));
    utils.ensureDir(path.join(__dirname, 'storages', 'introductions'));
    utils.ensureDir(path.join(__dirname, 'storages', 'system_files'));
    utils.ensureDir(path.join(__dirname, 'news'));
    utils.ensureDir(path.join(__dirname, 'public'));
    utils.ensureDir(path.join(__dirname, 'temp'));
    utils.ensureDir(path.join(__dirname, 'frhc'));
}

function startServices() {
    initDirs();
    const mainApp = createMainApp();
    mainApp.listen(10377, () => {
        console.log(`${CONFIG.getMainApiUrl()}`);
    });
    const verifyApp = createVerifyApp();
    verifyApp.listen(80, () => {
    }).on('error', (err) => {
        if (err.code === 'EACCES') {
        } else {
            console.error(err.message);
        }
    });
    setInterval(() => {
        const keysDir = path.join(__dirname, 'keys');
        if (!fs.existsSync(keysDir)) return;
        
        const now = new Date();
        const uidDirs = fs.readdirSync(keysDir);
        
        uidDirs.forEach(uid => {
            const vkeyPath = path.join(keysDir, uid, 'vkey.conf');
            if (fs.existsSync(vkeyPath)) {
                const vkeyData = utils.readConf(vkeyPath);
                if (vkeyData && vkeyData.latest) {
                    const [h, m, s] = vkeyData.latest.split(':').map(Number);
                    const latestTime = new Date();
                    latestTime.setHours(h, m, s);
                    const diff = (now - latestTime) / 1000 / 60;
                    
                    if (diff > 30) {
                        fs.rmSync(path.join(keysDir, uid), { recursive: true, force: true });
                    }
                }
            }
        });
    }, 30 * 60 * 1000);

    const scheduleCleanup = () => {
        const now = new Date();
        const nextHour = new Date();
        nextHour.setHours(now.getHours() >= 12 ? 24 : 12, 0, 0, 0);
        const delay = nextHour - now;
        
        setTimeout(() => {
            const keysDir = path.join(__dirname, 'keys');
            if (fs.existsSync(keysDir)) {
                const uidDirs = fs.readdirSync(keysDir);
                uidDirs.forEach(uid => {
                    fs.rmSync(path.join(keysDir, uid), { recursive: true, force: true });
                });
            }
            scheduleCleanup();
        }, delay);
    };
    scheduleCleanup();
}
startServices();
